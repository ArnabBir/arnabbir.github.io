# Taskflow — a React + Java learning reference

A small working vertical slice: create, list, complete and delete tasks through a typed React UI and a real Spring Boot API. Read this code alongside Project 07 in Frontend Atlas.

This reference runs on localhost. Data lives in memory and resets when the Java process stops. Authentication, durable persistence, title editing, idempotent creates, version-conflict handling and production deployment are capstone extension work, not implemented claims.

## Run it

You need Java 17+, Maven 3.6.3+, and a Node version supported by the pinned Vite 7 toolchain (Node 22.12+ is suitable). The tested machine used Java 17, Maven 3.9 and Node 24.

Terminal 1:

```sh
cd backend
mvn spring-boot:run
```

Terminal 2:

```sh
cd frontend
npm ci
npm run dev
```

Open the URL Vite prints, normally `http://127.0.0.1:5173`. Its development proxy forwards `/api` to `http://127.0.0.1:8080`.

```sh
# Frontend type checking and production build
cd frontend
npm run build

# Java package
cd ../backend
mvn package
```

The production frontend output does not include the Vite development proxy. Configure a production reverse proxy explicitly before deployment.

## Follow one write

1. `src/main.tsx` owns the title draft and handles form submission.
2. `src/api.ts` sends a POST request and checks the HTTP response.
3. `TaskController.create` validates input, trims the title, generates a string ID and writes to the in-memory map.
4. `parseTask` validates the returned JSON shape at runtime.
5. React adds the confirmed task to state and clears the draft. A failed operation preserves the draft and presents the error.

The initial list request uses both AbortController and a relevance flag. Cleanup prevents a completed obsolete request from updating the component. Writes are confirmation-first and the demo serializes UI mutations; this is not a server idempotency guarantee.

## API contract

| Operation | Request | Success | Important failure |
| --- | --- | --- | --- |
| List | `GET /api/tasks` | 200 task array, newest first with ID tie-breaker | transport/server failure |
| Read | `GET /api/tasks/{id}` | 200 task | 404 |
| Create | `POST /api/tasks` with `{ "title": "Learn Grid" }` | 201 task and Location | 400 blank or over 120 characters |
| Complete | `PATCH /api/tasks/{id}` with `{ "done": true }` | 200 updated task | 400 missing boolean, 404 |
| Delete | `DELETE /api/tasks/{id}` | 204 without JSON body | 404 |

Task shape: `{ id: string, title: string, done: boolean, updatedAt: ISO timestamp }`.

## Extend it in this order

1. Add title editing with a preserved draft and clear validation errors.
2. Add a database, schema migration and repository tests.
3. Add a version or ETag contract, enforcing stale-write rejection on the server.
4. Define an idempotency strategy for retries after ambiguous create outcomes.
5. Integrate authentication and enforce task ownership on every endpoint.
6. Define CSRF, session-cookie, CORS and logout behavior for the chosen topology.
7. Add component tests and a browser journey against the real API.
8. Deploy with HTTPS, deliberate asset caching, API routing, monitoring and rollback.

## Verified for this delivery

- Java application packaged and started successfully.
- Frontend passed full TypeScript checking and a Vite production build.
- Real HTTP checks passed for create, list, get, completion update and deletion.
- Blank and oversized titles, missing completion value and missing resource behavior were checked.
- A real browser created and completed a task through the Vite proxy; the completed task was retained after page reload while Spring remained running.

Dependency versions are pinned by the lockfile and Maven parent for reproducibility. Review current maintenance and security requirements before turning this local teaching reference into a deployed application.
