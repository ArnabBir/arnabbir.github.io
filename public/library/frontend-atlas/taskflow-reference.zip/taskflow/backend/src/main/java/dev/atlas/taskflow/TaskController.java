package dev.atlas.taskflow;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.net.URI;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Local teaching reference: in-memory data, no authentication. */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    public record Task(String id, String title, boolean done, Instant updatedAt) {}
    public record Draft(@NotBlank @Size(max = 120) String title) {}
    public record Completion(@NotNull Boolean done) {}
    private final ConcurrentHashMap<String, Task> tasks = new ConcurrentHashMap<>();

    @GetMapping
    public List<Task> list() {
        return tasks.values().stream()
            .sorted(Comparator.comparing(Task::updatedAt).reversed().thenComparing(Task::id))
            .toList();
    }

    @PostMapping
    public ResponseEntity<Task> create(@Valid @RequestBody Draft draft) {
        String id = UUID.randomUUID().toString();
        Task task = new Task(id, draft.title().strip(), false, Instant.now());
        tasks.put(id, task);
        return ResponseEntity.created(URI.create("/api/tasks/" + id)).body(task);
    }

    @GetMapping("/{id}")
    public Task get(@PathVariable String id) {
        Task task = tasks.get(id);
        if (task == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
        return task;
    }

    @PatchMapping("/{id}")
    public Task complete(@PathVariable String id, @Valid @RequestBody Completion completion) {
        return tasks.compute(id, (key, current) -> {
            if (current == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
            return new Task(key, current.title(), completion.done(), Instant.now());
        });
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (tasks.remove(id) == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
        return ResponseEntity.noContent().build();
    }
}
