import { StrictMode, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createTask, listTasks, removeTask, setTaskDone, type Task } from './api';
import './style.css';
type Load = 'loading' | 'success' | 'error';
function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [status, setStatus] = useState<Load>('loading');
  const [error, setError] = useState('');
  const [title, setTitle] = useState('');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [reload, setReload] = useState(0);
  const [notice, setNotice] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    let current = true;
    setStatus('loading'); setError('');
    listTasks(controller.signal).then(data => {
      if (current) { setTasks(data); setStatus('success'); }
    }).catch(reason => {
      if (current && !controller.signal.aborted) { setError(String(reason.message || reason)); setStatus('error'); }
    });
    return () => { current = false; controller.abort(); };
  }, [reload]);
  async function mutate(operation: () => Promise<void>) {
    if (busyRef.current || status !== 'success') return;
    busyRef.current = true; setBusy(true); setError(''); setNotice('');
    try { await operation(); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'The change could not be saved.'); }
    finally { busyRef.current = false; setBusy(false); }
  }
  const visible = tasks.filter(t => t.title.toLowerCase().includes(query.toLowerCase()) && (filter === 'all' || (filter === 'done' ? t.done : !t.done)));
  return <main>
    <header><span className="eyebrow">FRONTEND ATLAS · REFERENCE PROJECT</span><h1>Make room for what’s next.</h1><p>Taskflow connects a typed React interface to a Java API.</p></header>
    <aside className="notice">Local learning demo · in-memory tasks reset when Spring restarts · no authentication.</aside>
    <form onSubmit={event => { event.preventDefault(); const draft = title.trim(); if (!draft) return; void mutate(async () => { const task = await createTask(draft); setTasks(current => [task, ...current]); setTitle(''); setNotice('Task saved to the local server.'); }); }}>
      <label htmlFor="title">Task title</label><div className="row"><input id="title" value={title} onChange={e => setTitle(e.target.value)} maxLength={120} required disabled={busy || status !== 'success'} placeholder="What would you like to learn?"/><button disabled={busy || status !== 'success' || !title.trim()}>{busy ? 'Saving…' : 'Add task'}</button></div>
    </form>
    <div className="filters"><label>Search<input type="search" value={query} onChange={e => setQuery(e.target.value)} /></label><label>Status<select value={filter} onChange={e => setFilter(e.target.value)}><option value="all">All tasks</option><option value="open">Open</option><option value="done">Complete</option></select></label><button className="secondary" disabled={busy || status === 'loading'} onClick={() => setReload(n => n + 1)}>Refresh</button></div>
    {status === 'loading' && <p role="status">Loading tasks…</p>}
    {error && <div className="error" role="alert">{error} {status === 'error' && <button onClick={() => setReload(n => n + 1)}>Retry</button>}</div>}
    <p role="status">{notice}</p>
    {status === 'success' && <><p className="count">{tasks.filter(t => t.done).length} of {tasks.length} complete · {visible.length} shown</p>{visible.length ? <ul>{visible.map(task => <li key={task.id}><label><input type="checkbox" checked={task.done} disabled={busy} onChange={() => void mutate(async () => { const updated = await setTaskDone(task.id, !task.done); setTasks(current => current.map(t => t.id === updated.id ? updated : t)); setNotice('Task updated.'); })}/><span className={task.done ? 'done' : ''}>{task.title}</span></label><button className="secondary" disabled={busy} aria-label={'Delete ' + task.title} onClick={() => void mutate(async () => { await removeTask(task.id); setTasks(current => current.filter(t => t.id !== task.id)); setNotice('Task deleted.'); })}>Delete</button></li>)}</ul> : <div className="empty">{tasks.length ? 'No tasks match these filters.' : 'A clear page. Add your first task above.'}</div>}</>}
    <footer>Extend this slice with durable storage, resource authorization, conflict detection and the capstone’s acceptance tests.</footer>
  </main>;
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
