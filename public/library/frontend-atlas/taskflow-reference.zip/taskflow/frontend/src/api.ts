export type Task = { id: string; title: string; done: boolean; updatedAt: string };
export function parseTask(value: unknown): Task {
  if (typeof value !== 'object' || value === null) throw new Error('Invalid task');
  const v = value as Record<string, unknown>;
  if (typeof v.id !== 'string' || typeof v.title !== 'string' || typeof v.done !== 'boolean' || typeof v.updatedAt !== 'string' || !Number.isFinite(Date.parse(v.updatedAt))) throw new Error('Invalid task response');
  return { id: v.id, title: v.title, done: v.done, updatedAt: v.updatedAt };
}
async function request(path: string, init: RequestInit = {}): Promise<unknown> {
  const response = await fetch('/api/tasks' + path, init);
  if (!response.ok) {
    let message = 'Request failed (HTTP ' + response.status + ').';
    try { const error: unknown = await response.json(); if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string') message = error.message; } catch { /* Preserve the useful status when an error body is not JSON. */ }
    throw new Error(message);
  }
  return response.status === 204 ? null : response.json();
}
export async function listTasks(signal?: AbortSignal): Promise<Task[]> {
  const value = await request('', {signal});
  if (!Array.isArray(value)) throw new Error('Expected a task list');
  return value.map(parseTask);
}
export async function createTask(title: string): Promise<Task> {
  return parseTask(await request('', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title})}));
}
export async function setTaskDone(id: string, done: boolean): Promise<Task> {
  return parseTask(await request('/' + encodeURIComponent(id), {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({done})}));
}
export async function removeTask(id: string): Promise<void> {
  await request('/' + encodeURIComponent(id), {method:'DELETE'});
}
